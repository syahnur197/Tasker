<div class="row justify-content-center">
    <?php echo $__env->make('tasks.pending', ["pending_tasks" => $pending_tasks], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('tasks.in_process', ["in_process_tasks" => $in_process_tasks], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('tasks.completed_today', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>