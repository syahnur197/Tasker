<?php $__env->startComponent('mail::message'); ?>
# Your Today's Tasks

Please refer to your tasks today
<?php if($pendingTasks->isNotEmpty()): ?>
## Pending Tasks
<?php $__currentLoopData = $pendingTasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
* <?php echo e($task->description); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
<?php endif; ?>

<?php if($inProcessTasks->isNotEmpty()): ?>
## In Process Tasks
<?php $__currentLoopData = $inProcessTasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
* <?php echo e($task->description); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

Thanks,<br>
<?php echo e(config('mail.from.name')); ?>

<?php echo $__env->renderComponent(); ?>
