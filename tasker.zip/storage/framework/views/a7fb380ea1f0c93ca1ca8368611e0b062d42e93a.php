<div class="col-md-4 mb-4">
	<div class="card">
		<div class="card-header bg-info text-white">In Process</div>
		<div class="card-body">
			<?php if($in_process_tasks->isEmpty()): ?>
				No In Process Tasks
			<?php endif; ?>
			<?php $__currentLoopData = $in_process_tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php echo $__env->make('tasks.task', ['task' => $task, 'status' => 2], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
</div>