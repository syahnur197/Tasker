<?php $__env->startSection('content'); ?>
<div class="row justify-content-center mb-2">
    <div class="col-md-12">
        <div class="card mb-2">
            <div class="card-header">Completed Tasks</div>
		</div>
		<?php
			$date = "";
		?>
		<?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php echo e($date == $task->completed_on ? NULL : "Task completed on : "); ?>

			<?php echo e($date = $date == $task->completed_on ? NULL : $task->completed_on); ?>

			<?php echo $__env->make('tasks.task', ['task' => $task, 'status' => 3], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>