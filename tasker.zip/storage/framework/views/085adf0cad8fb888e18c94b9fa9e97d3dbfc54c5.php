<?php $__env->startSection('content'); ?>
<div class="row justify-content-center mb-2">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">Edit Task</div>
            <div class="card-body">
                <?php echo $__env->make('tasks.form', ['form' => 'edit', 'task' => $task], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>