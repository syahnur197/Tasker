<?php $__env->startSection('content'); ?>
<div class="row justify-content-center mb-4">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header bg-primary text-white">Create Task</div>
            <div class="card-body">
                <?php echo $__env->make('tasks.form', ['form' => 'create', 'task' => '', 'users' => $users], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('tasks.my_task', ["pending_tasks" => $pending_tasks, "in_process_tasks" => $in_process_tasks], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>