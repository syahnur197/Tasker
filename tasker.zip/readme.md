#To Do List

- [ ] Super Admin to assign task to users
- [ ] Receive notification or email when admin assigned task
- [ ] Super Admin can view other's tasks
- [ ] Super Admin can update or delete other's tasks
- [ ] Different User levels
	- [ ] Super Admin (CEO, COO, and Me duhh)
	- [ ] Admin (CTO, CMO, CIO)
	- [ ] Head Project (if ada project module)
	- [ ] Developers