<div class="col-md-4 mb-4">
	<div class="card">
		<div class="card-header bg-warning">Pending</div>
		<div class="card-body">
			<?php if($pending_tasks->isEmpty()): ?>
				No Pending Tasks
			<?php endif; ?>
			<?php $__currentLoopData = $pending_tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php echo $__env->make('tasks.task', ['task' => $task, 'status' => 1], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
</div>