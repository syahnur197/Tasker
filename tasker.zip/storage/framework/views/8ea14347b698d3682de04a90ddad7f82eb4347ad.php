<?php if(!empty($quote)): ?>
	<blockquote class="blockquote text-center border-right">
		<p class="mb-0"><?php echo e($quote->quoteText); ?></p>
		<footer class="blockquote-footer"><?php echo e($quote->quoteAuthor); ?></footer>
	</blockquote>
<?php endif; ?>