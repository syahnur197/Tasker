<div class="card bg-dark text-light p-3 mb-2">
	<?php if(Request::is('dashboard')): ?>
		<div class="row no-gutters">
			<div class="<?php echo e($status == 1 || $status == 2 ? 'col-3 col-lg-3 col-md-3 mr-1' : ''); ?>">
				<?php if($status === 1): ?>
					<form method="POST" action="/tasks/<?php echo e($task->id); ?>/start">
						<?php echo csrf_field(); ?>
						<button class="btn btn-primary btn-block btn-sm">
							Start
						</button>
					</form>
				<?php endif; ?>
				<?php if($status === 2): ?>
					<form method="POST" action="/tasks/<?php echo e($task->id); ?>/stop">
						<?php echo csrf_field(); ?>
						<button class="btn btn-success btn-block btn-sm">
							End
						</button>
					</form>
				<?php endif; ?>
			</div>
			<div class="col-3 col-lg-3 col-md-3">
				<a href="/tasks/<?php echo e($task->id); ?>/edit" class="btn btn-block btn-warning btn-sm">
					Edit
				</a>
			</div>
			<div class="col-3 col-lg-3 col-md-3 ml-1">
				<form action="/tasks/<?php echo e($task->id); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete task?');">
					<?php echo method_field('DELETE'); ?>
					<?php echo csrf_field(); ?>
					<button type="submit" class="btn btn-block btn-danger btn-sm">
						Delete
					</button>
				</form>
			</div>
		</div>
	<?php endif; ?>
	<div class="row">
		<div class="col-12 col-lg-12 col-md-12">
			<h5 class="mb-0 mt-2"><?php echo e($task->description); ?></h5>
		</div>
	</div>
	<?php if($task->start_date !== NULL && $task->completed_on == NULL): ?>
		<p class="mb-0">Start Date: <?php echo e(Carbon\Carbon::parse($task->start_date)->format('d M Y')); ?></p>
	<?php endif; ?>
	<?php if($task->end_date !== NULL && $task->completed_on == NULL): ?>
		<p class="mb-0">End Date: <?php echo e(Carbon\Carbon::parse($task->end_date)->format('d M Y')); ?></p>
	<?php endif; ?>
	<?php if($task->completed_on !== NULL): ?>
		<p class="mb-0">Completed Date: <?php echo e(Carbon\Carbon::parse($task->completed_on)->format('d M Y')); ?></p>
	<?php endif; ?>
</div>

 