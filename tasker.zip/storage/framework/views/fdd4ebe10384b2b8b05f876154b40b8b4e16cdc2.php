<?php $__env->startSection('content'); ?>
<div class="row justify-content-center mb-4">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header bg-primary text-white">Select Users</div>
            <div class="card-body">
                <form action="/users" method="GET" onchange="this.submit()">
                    <div class="row">
                    	<div class="col-lg-10 col-md-10 col-8">
                    		<select class="form-control" name='owner_id' id="owner_id">
                                <option value="">Please Choose</option>
                    		    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        							<option value="<?php echo e($user->id); ?>" <?php echo e(Request::get('owner_id')== $user->id ? "selected" : ""); ?>><?php echo e($user->name); ?></option>
        						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    		</select>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php if(!empty($user)): ?>
    <?php echo $__env->make('tasks.my_task', ["pending_tasks" => $pending_tasks, "in_process_tasks" => $in_process_tasks], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>